"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DESERIALIZATION_POPOUT_DELAY_MS = exports.DEFAULT_FLOATING_GROUP_POSITION = exports.DEFAULT_FLOATING_GROUP_OVERFLOW_SIZE = void 0;
exports.DEFAULT_FLOATING_GROUP_OVERFLOW_SIZE = 100;
exports.DEFAULT_FLOATING_GROUP_POSITION = { left: 100, top: 100, width: 300, height: 300 };
exports.DESERIALIZATION_POPOUT_DELAY_MS = 100;
